<?php
mysql_connect('localhost','','');
mysql_select_db("test");
if(isset($_GET['name']))
{

  $name=mysql_real_escape_string($_GET['name']);
  $query=mysql_query("SELECT * FROM 'test_image' WHERE 'name'='$name'");
  while($row=mysql_fetch_assoc($query))
   {
     $imageData=$row["image"];
    }
    header("content-type:image/jpeg");	
	echo $imageData;
  }
  else
  {
   echo "Error!";
   }
 ?>  