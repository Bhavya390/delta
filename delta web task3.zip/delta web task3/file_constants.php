<?php
$host="localhost";
$user="";
$pass="";

?>
