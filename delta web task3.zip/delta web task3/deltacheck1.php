<html>
<style>
h1
{
	color:black;
    text-align:center;


}
</style>
<body>

<?php
	ob_start();
	extract($_POST);
	session_start();
$conn = mysql_connect('localhost','','');
if(!$conn)
{
	die("Could not open a connection to database on localhost");
}

$stat = mysql_select_db('test');
if(!$stat)
{
	die("Could not select the specified database");
}

$query = "SELECT * FROM deltaregistration where( rollno='$rollno' AND password='$password')";

$status = mysql_query($query);
echo mysql_num_rows($status);
	if(isset($rollno) && $rollno != 0)
	{
		$_SESSION["rollno"] = $rollno;
	}
	else{
	echo"<h1>rollno and password not matching</h1>";
	}
	
	//ob_flush();


if(mysql_num_rows($status)== 0)

{
	
	echo"<h1>rollno&password not matching</h1>";
	header('location:logindelta.html');
	
}
else
{  
	header('location:file_insert.php');
	}
	
mysql_close($conn);

?>

</body>
</html>

