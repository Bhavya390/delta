-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 28, 2014 at 05:33 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `deltaregistration`
--

CREATE TABLE IF NOT EXISTS `deltaregistration` (
  `name` varchar(200) DEFAULT NULL,
  `rollno` int(8) DEFAULT NULL,
  `dept` varchar(200) DEFAULT NULL,
  `gender` varchar(30) DEFAULT NULL,
  `password` varchar(200) DEFAULT NULL,
  `confirmpassword` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `deltaregistration`
--

INSERT INTO `deltaregistration` (`name`, `rollno`, `dept`, `gender`, `password`, `confirmpassword`) VALUES
('Bhavya', 106113019, 'Computerscience', 'female', 'mango2', 'mango2'),
('Ananya', 106113010, 'Computerscience', 'female', 'green2', 'green2'),
('Gokul', 106113032, 'Computerscience', 'male', 'goodbye', 'goodbye'),
('Pragna', 106113054, 'Computerscience', 'female', 'iloveapple', 'iloveapple'),
('Akshay', 106113007, 'Computerscience', 'male', 'mangogo', 'mangogo');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
