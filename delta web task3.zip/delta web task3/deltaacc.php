<html>
<style>

h1
{
	color:white;
    text-align:left;


}
html{
background:url(black.jpg)no-repeat center center fixed;
-webkit-background-size:cover;
-moz-background-size:cover;
background-size:cover;
}
</style>
<body>
<?php
ob_start();
	extract($_POST);
	session_start();
$conn = mysqli_connect('localhost','','');
if(!$conn)
{
	die("Could not open a connection to database on localhost");
}

$stat = mysqli_select_db($conn,"test");
if(!$stat)
{
	die("Could not select the specified database");
}
$query1 = "SELECT rollno FROM deltaregistration where rollno='$rollno'";
$status1 = mysqli_query($conn,$query1);
if(mysqli_num_rows($status1)!=0)
{
	echo"<h1>rollno already exists or some fields r empty</h1>";
	 header('location:deltares.html');
	}
	
$query = "INSERT INTO deltaregistration VALUES('$name','$rollno','$dept','$gender','$password','$confirmpassword')";

$status = mysqli_query($conn,$query);

echo $status;
if(!$status)
{
	die("Could not execute query");
}

if($name == "" || $password== "" || $confirmpassword==""|| $rollno==""||$gender==""||$dept=="")
{
  echo "<h1>Some fields * are not filled</h1> ";
  $q="DELETE FROM `deltaregistration` WHERE rollno=0";
  $s=mysqli_query($conn,$q);
 header('location:deltares.html');
  }
else
{
	echo "<h1>REGISTERD Successfully!!!</h1>";
}

mysqli_close($conn);

?>

<a href="logindelta.html"><input type="submit" value="Backtologinpage" /></a>

</body>
</html>
