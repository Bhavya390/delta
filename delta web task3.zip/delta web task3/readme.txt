USER NAME:Bhavyashree.p
PROFILE: Web Development
NAME OF THE TASK: student database

to view image 
localhost/showimage.php?name=[imagename]
works in firefox

uploaded five student details in database 
images stored in file images
i used blob type to store images in database.
test_image table to upload images

 